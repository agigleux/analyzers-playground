package org.sonarlint;

public class Cup {

  public boolean isFilled() {
    return false;
  }

}
