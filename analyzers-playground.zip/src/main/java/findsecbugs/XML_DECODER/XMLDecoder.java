package findsecbugs.XML_DECODER;

public class XMLDecoder {
  public static void main(String[] args) {

  }
}
