public class MyException extends RuntimeException {

  private static final long serialVersionUID = 2108190271234950435L;

}
